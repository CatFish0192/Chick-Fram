import os
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide" #关闭pygame版本信息显示
import pygame
import time #测试需要


pygame.mixer.init()

pygame.key.stop_text_input()
music_files = [os.path.join("music", f) for f in os.listdir("music") if f.endswith(('.mp3', '.ogg'))]

if music_files:
    current_index = 0
    if 0 <= current_index < len(music_files):
        pygame.mixer.music.load(music_files[current_index])
        pygame.mixer.music.play(-1)  # 循环播放
    print("《我是XJZY》")
    time.sleep(1)