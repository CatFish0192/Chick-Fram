pip3 install colorama
tar -xzvf XJZY-2.9Beta6.tar.gz
cd XJZY-2.9Beta6
chmod +x XJZY-2.9Beta6.py
echo 已安装