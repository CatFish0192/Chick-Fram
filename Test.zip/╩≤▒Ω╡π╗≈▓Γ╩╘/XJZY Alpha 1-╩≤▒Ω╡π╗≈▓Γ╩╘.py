import keyboard

def on_key_press(event):
    if event.name == "f1":
        print("f1")
    elif event.name == "f2":
        print("f2")
    elif event.name == "f3":
        print("f3")

keyboard.on_press(on_key_press)
keyboard.wait("esc")