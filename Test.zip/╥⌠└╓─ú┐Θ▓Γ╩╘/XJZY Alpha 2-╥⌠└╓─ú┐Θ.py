import os
import pygame
import keyboard #注：keyboard只是为了保持播放，正式开发时不需要

pygame.init()
pygame.mixer.init()

def play_music(music_files, index):
    if 0 <= index < len(music_files):
        pygame.mixer.music.load(music_files[index])
        pygame.mixer.music.play(-1)  # 循环播放

def on_key_press(event):
    global music_files
    global current_index
    if event.name == "f2":
        # 按F2暂停/恢复播放
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
        else:
            pygame.mixer.music.unpause()
    elif event.name == "f1":
        # 按F1播放上一个音乐
        current_index = (current_index - 1) % len(music_files)
        play_music(music_files, current_index)
    elif event.name == "f3":
        # 按F3播放下一个音乐
        current_index = (current_index + 1) % len(music_files)
        play_music(music_files, current_index)

pygame.key.stop_text_input()
music_files = [os.path.join("music", f) for f in os.listdir("music") if f.endswith(('.mp3', '.ogg'))]

if music_files:
    current_index = 0
    play_music(music_files, current_index)  # 播放第一首音乐
    keyboard.on_press(on_key_press)
    keyboard.wait("esc")